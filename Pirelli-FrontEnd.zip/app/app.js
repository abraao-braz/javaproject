'use strict';

// Declare app level module which depends on views, and components
angular.module('PirelliApp', [
  'ngRoute',
  'ngResource',
  'ngAnimate',
  'angular-loading-bar',
  'PirelliApp.login',
  'PirelliApp.buscaveiculo',
  'PirelliApp.buscamedida',
  'PirelliApp.detalheproduto',
  'PirelliApp.selecao',
  'PirelliApp.marca',
  'PirelliApp.carroceria',
  'PirelliApp.segmento',
  'PirelliApp.medida',
  'PirelliApp.modelo',
  'PirelliApp.produto',
  'PirelliApp.usuario',
  'PirelliApp.configuracoes',
  'PirelliApp.concorrente',
  'PirelliApp.tabelaequivalencia'
  
])
.config(['$locationProvider', '$routeProvider', function($locationProvider, $routeProvider) {
  $locationProvider.hashPrefix('!');
  //Verificar se está logado e dar o redirect
  
  $routeProvider.otherwise({redirectTo: '/login'});
}])
.config(['cfpLoadingBarProvider', function(cfpLoadingBarProvider) {
    cfpLoadingBarProvider.parentSelector = 'painel_dinamico';
    cfpLoadingBarProvider.spinnerTemplate = '<div class="sk-folding-cube">  <div class="sk-cube1 sk-cube"></div>  <div class="sk-cube2 sk-cube"></div>  <div class="sk-cube4 sk-cube"></div>  <div class="sk-cube3 sk-cube"></div></div>';
  }])
