'use strict';

angular.module('PirelliApp.usuario', ['ngRoute', 'angular-loading-bar','PirelliApp.configuracoes'])

        .config(['$routeProvider', function ($routeProvider, $routeParams) {
                $routeProvider
                        .when('/usuario', {
                            templateUrl: 'paginas/usuario/index.html',
                        })
                        .when('/usuario/novo', {
                            templateUrl: 'paginas/usuario/novo.html',
                        })
                        .when('/usuario/editar/:id', {
                            templateUrl: 'paginas/usuario/novo.html',
                        })
                        
                        ;
            }])

        .controller('UsuarioController', ['$scope', '$location', '$http', 'ConfigFactory', function ($scope, $location, $http,ConfigFactory) {
                $scope.carregado = "hidden";
                $scope.classePermissao = ConfigFactory.getClasse();
                $scope.pagina = 1;
                $scope.tamanho = 20;
                $scope.total = 0;
                $scope.paginacao = [];

                $scope.getTipo = function(id){
                  if(id==1) return "Administrador";  
                  if(id==2) return "Loja";
                  else return "XXX";
                };             
                
                $scope.trocaPagina = function(pagina){
                    console.log("Troca pagina");
                    $scope.pagina = pagina;
                    $scope.atualizar();
                }
                
                $scope.atualizar = function(){
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl()+'/usuario?pagina='+$scope.pagina+'&tamanho='+$scope.tamanho,
                        headers: {
                            'Content-Type': 'application/json;charset=ISO-8859-1',
                        }
                    }).then(function successCallback(response) {
                        $scope.listagem = response.data.dados;
                        $scope.total = response.data.paginacao.total;
                        $scope.paginacao = [];
                        var i;
                        var indice = 0;
                        var inicio = 1;
                        var fim = $scope.total;
                        
                        for(i=inicio;i<=fim;i++){
                           $scope.paginacao[indice] = i;
                           indice++;
                        }
                        

                        
                        $scope.carregado = "display";
                    }, function errorCallback(response) {
                        console.log("erro");
                    });

                }
                
                $scope.deletar = function (id) {

                    swal({
                        title: "Confirmação",
                        text: "Tem certeza que deseja excluir este usuario?",
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#DD6B55",
                        confirmButtonText: "SIM",
                        closeOnConfirm: true
                    },
                    function () {
                        $http({
                            method: 'DELETE',
                            url: ConfigFactory.getUrl()+'/usuario/'+id,
                            headers: {
                                'Content-Type': 'application/json;charset=ISO-8859-1',
                            }
                        }).then(function successCallback(response) {
                            toastr.success(response.data.descricao, 'Sucesso')
                            $scope.atualizar();
                        }, function errorCallback(response) {

                        });
                    });

                };
                $scope.atualizar();

            }])
        .controller('UsuarioFormController', ['$scope', '$location', '$http', '$routeParams','ConfigFactory', function ($scope, $location,$http, $routeParams, ConfigFactory) {

                $scope.tipos = [
                    {id:1, descricao:"Administrador"},
                    {id:2, descricao:"Loja"}
                ];
                

                
                
                $scope.buscar = function(id){
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl()+'/usuario/'+id,
                        headers: {
                            'Content-Type': 'application/json;charset=ISO-8859-1',
                        }
                    }).then(function successCallback(response) {
                       $scope.usuario = response.data;
                        
                    }, function errorCallback(response) {

                    });
                    
                }
                
                
                $scope.cadastrar = function (dados) {
                    var metodo = "POST";
                    if(dados.id) metodo = "PUT";
                   
                    $http({
                        method: metodo,
                        url: ConfigFactory.getUrl()+'/usuario',
                        headers: {
                            'Content-Type': 'application/json;charset=ISO-8859-1',
                        },
                        data: dados
                    }).then(function successCallback(response) {
                        toastr.success(response.data.descricao, 'Sucesso')
                        $location.path('/usuario');
                    }, function errorCallback(response) {

                    });



                };
                
                if($routeParams.id){
                    $scope.buscar($routeParams.id);
                    $scope.titulo = "Editar Usuário";
                }
                else{
                    $scope.titulo = "Novo Usuário";
                }


            }]);