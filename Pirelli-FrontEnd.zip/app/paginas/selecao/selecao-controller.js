'use strict';

angular.module('PirelliApp.selecao', ['ngRoute','ngResource'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/selecao', {
    templateUrl: 'paginas/selecao/selecao.html',
    controller: 'SelecaoController'
  });
}])

.controller('SelecaoController', [function() {

}]);