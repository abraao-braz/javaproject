'use strict';

angular.module('PirelliApp.modelo', ['ngRoute', 'angular-loading-bar', 'PirelliApp.configuracoes','angularModalService'])

        .config(['$routeProvider', function ($routeProvider, $routeParams) {
                $routeProvider
                        .when('/modelo', {
                            templateUrl: 'paginas/modelo/index.html',
                        })
                        .when('/modelo/novo', {
                            templateUrl: 'paginas/modelo/novo.html',
                        })
                        .when('/modelo/editar/:id', {
                            templateUrl: 'paginas/modelo/novo.html',
                        })

                        ;
        }])

        .controller('ModeloController', ['$scope', '$location', '$http', 'ConfigFactory', function ($scope, $location, $http, ConfigFactory) {
                $scope.carregado = "hidden";
                $scope.classePermissao = ConfigFactory.getClasse();
                $scope.pagina = 1;
                $scope.tamanho = 20;
                $scope.total = 0;
                $scope.paginacao = [];   
                $scope.blocopaginacao = 1;

                $scope.trocaBloco = function(pagina){
                    $scope.blocopaginacao+=pagina;
                    if($scope.blocopaginacao<1) $scope.blocopaginacao=1;
                    if($scope.blocopaginacao>Math.ceil($scope.total / 10) ) $scope.blocopaginacao=Math.ceil($scope.total / 10);
                    $scope.pagina = ($scope.blocopaginacao-1) * 10 + 1;
                    $scope.atualizar();
                }

                $scope.trocaPagina = function(pagina){
                    $scope.pagina = pagina;
                    $scope.atualizar();
                }


                $scope.atualizar = function () {
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/modelo?pagina='+$scope.pagina+'&tamanho='+$scope.tamanho,
                        headers: {
                            'Content-Type': 'application/json;charset=ISO-8859-1',
                        }
                    }).then(function successCallback(response) {
                        $scope.listagem = response.data.dados;
                        $scope.total = response.data.paginacao.total;
                        $scope.paginacao = [];
                        var i;
                        var indice = 0;
                        var inicio = ($scope.blocopaginacao-1) * 10 + 1 ;
                        var fim = inicio + 9;
                        if(fim>$scope.total) fim = $scope.total;
                        
                        
                        
                        
                        for(i=inicio;i<=fim;i++){
                           $scope.paginacao[indice] = i;
                           indice++;
                        }
                        
                        $scope.carregado = "display";
                    }, function errorCallback(response) {
                        console.log("erro");
                    });

                }

                $scope.deletar = function (id) {

                    swal({
                        title: "Confirmação",
                        text: "Tem certeza que deseja excluir este modelo?",
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#DD6B55",
                        confirmButtonText: "SIM",
                        closeOnConfirm: true
                    },
                    function () {
                        $http({
                            method: 'DELETE',
                            url: ConfigFactory.getUrl() + '/modelo/' + id,
                            headers: {
                                'Content-Type': 'application/json;charset=ISO-8859-1',
                            }
                        }).then(function successCallback(response) {
                            toastr.success(response.data.descricao, 'Sucesso')
                            $scope.atualizar();
                        }, function errorCallback(response) {

                        });
                    });

                };
                $scope.atualizar();

        }])
        .controller('ModeloFormController', ['$scope', '$location', '$http', '$routeParams', 'ConfigFactory', 'ModalService', function ($scope, $location, $http, $routeParams, ConfigFactory, ModalService) {

                    $scope.novaversao = function(idModelo, idVersao){                 
                    ModalService.showModal({
                          templateUrl: "paginas/modelo/modal.html",
                          controller: "ComplexController",
                          inputs: {
                            title: "Adicionar nova versão",
                            idModelo: idModelo,
                            idVersao: idVersao,
                          }
                        }).then(function(modal) {
                          modal.element.modal();
                          modal.close.then(function(result) {
                            $scope.buscarVersao(idModelo);  
                            
                          });
                    });                  
                };
                
                
                $scope.buscar = function (id) {
                    //Buscar os dados do modelo
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/modelo/' + id,
                        headers: {
                            'Content-Type': 'application/json;charset=ISO-8859-1',
                        }
                    }).then(function successCallback(response) {
                        $scope.modelo = response.data;

                    }, function errorCallback(response) {

                    });
                }
                
                $scope.buscarVersao = function (id) {

                    
                    //Buscar a lista de versões deste modelo
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/versao/modelo/'+id,
                        headers: {
                            'Content-Type': 'application/json;charset=ISO-8859-1',
                        }
                    }).then(function successCallback(response) {
                        $scope.versoes = response.data;

                    }, function errorCallback(response) {

                    });                    

                };        
                
                $scope.deletarVersao = function (idVersao, idModelo) {
                    
                    swal({
                        title: "Confirmação",
                        text: "Tem certeza que deseja excluir esta versão?",
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#DD6B55",
                        confirmButtonText: "SIM",
                        closeOnConfirm: true
                    },
                    function () {
                        $http({
                            method: 'DELETE',
                            url: ConfigFactory.getUrl() + '/versao/' + idVersao,
                            headers: {
                                'Content-Type': 'application/json;charset=ISO-8859-1',
                            }
                        }).then(function successCallback(response) {
                            toastr.success(response.data.descricao, 'Sucesso')
                            $scope.buscarVersao(idModelo);
                        }, function errorCallback(response) {
                            toastr.success('Erro ao excluir versão', 'Erro')
                        });
                    });

                };                


                $scope.cadastrar = function (dados) {
                    
                    console.log(dados);
                    var metodo = "POST";
                    if (dados.id)
                        metodo = "PUT";

                    $http({
                        method: metodo,
                        url: ConfigFactory.getUrl() + '/modelo',
                        headers: {
                            'Content-Type': 'application/json;charset=ISO-8859-1',
                        },
                        data: dados
                    }).then(function successCallback(response) {
                        toastr.success(response.data.descricao, 'Sucesso')
                        $location.path('/modelo');
                    }, function errorCallback(response) {

                    });
                };
                
                
                $scope.geracombos = function(){
                   //Buscar as montadoras
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/montadora?pagina=1&tamanho=1000',
                        headers: {
                            'Content-Type': 'application/json;charset=ISO-8859-1',
                        }
                    }).then(function successCallback(response) {
                        $scope.montadoras = response.data.dados;

                    }, function errorCallback(response) {

                    });
                    //Buscar as carrocerias
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/carroceria?pagina=1&tamanho=1000',
                        headers: {
                            'Content-Type': 'application/json;charset=ISO-8859-1',
                        }
                    }).then(function successCallback(response) {
                        $scope.carrocerias = response.data.dados;

                    }, function errorCallback(response) {

                    });   
                    //Buscar os segmentos
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/segmento?pagina=1&tamanho=1000',
                        headers: {
                            'Content-Type': 'application/json;charset=ISO-8859-1',
                        }
                    }).then(function successCallback(response) {
                        $scope.segmentos = response.data.dados;

                    }, function errorCallback(response) {

                    });                      
                    
                }

                if ($routeParams.id) {
                    $scope.buscar($routeParams.id);
                    $scope.buscarVersao($routeParams.id);
                    $scope.titulo = "Editar Modelo";
                    $scope.ocultarabas = "display";
                }
                else {
                    $scope.titulo = "Novo Modelo";
                    $scope.ocultarabas = "hidden";
                }
                
                $scope.geracombos();


            }])
        
        .controller('ComplexController', ['$scope', '$http','$element', 'title', 'idModelo','idVersao', 'close', 'ConfigFactory', function($scope, $http, $element, title, idModelo, idVersao, close, ConfigFactory) {

            $scope.name = null;
            $scope.age = null;
            $scope.title = title;
            $scope.idModelo = idModelo;
            $scope.idVersao = idVersao;
            $scope.versao = {modelo:{id:idModelo}};
            
            $scope.getMedidasTotal = function(){
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/medida?pagina=1&tamanho=1000',
                        headers: {
                            'Content-Type': 'application/json',
                        }
                    }).then(function successCallback(response) {
                        $scope.medidasTotal = response.data.dados;
                    }, function errorCallback(response) {
                        console.log("erro");
                    });               
            }            
            
            
            $scope.getMedidas = function(){
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/medida/vinculadas?pagina=1&tamanho=1000',
                        headers: {
                            'Content-Type': 'application/json',
                        }
                    }).then(function successCallback(response) {
                        $scope.medidas = response.data.dados;
                    }, function errorCallback(response) {
                        console.log("erro");
                    });               
            }
            
            
            $scope.getVersao = function(id){
                $http({
                        method: "GET",
                        url: ConfigFactory.getUrl() + '/versao/'+id,
                        headers: {
                            'Content-Type': 'application/json;charset=ISO-8859-1',
                        }
                    }).then(function successCallback(response) {
                        $scope.versao = response.data;
                    }, function errorCallback(response) {

                    });                
            };

            //  This close function doesn't need to use jQuery or bootstrap, because
            //  the button has the 'data-dismiss' attribute.
            $scope.close = function(versao) {
                console.log("fechando");
                console.log(versao);
                var method = "POST";
                if($scope.idVersao!=null) method = "PUT";
                
                $http({
                        method: method,
                        url: ConfigFactory.getUrl() + '/versao',
                        headers: {
                            'Content-Type': 'application/json;charset=ISO-8859-1',
                        },
                        data: versao
                    }).then(function successCallback(response) {
                        toastr.success(response.data.descricao, 'Sucesso')
                    }, function errorCallback(response) {

                });
                
                    close({
                name: $scope.name,
                age: $scope.age
              }, 500); // close, but give 500ms for bootstrap to animate
            };
            


            //  This cancel function must use the bootstrap, 'modal' function because
            //  the doesn't have the 'data-dismiss' attribute.
            $scope.cancel = function() {

              //  Manually hide the modal.
              $element.modal('hide');

              //  Now call close, returning control to the caller.
              close({
                name: $scope.name,
                age: $scope.age
              }, 500); // close, but give 500ms for bootstrap to animate
            };
            
            if(idVersao!=null) $scope.getVersao(idVersao);
            $scope.getMedidas();
            $scope.getMedidasTotal();
            
}]);