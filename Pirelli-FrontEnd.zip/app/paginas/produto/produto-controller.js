'use strict';
var appProduto = angular.module('PirelliApp.produto', ['ngRoute', 'angular-loading-bar', 'PirelliApp.configuracoes', 'angularModalService', 'ui.select', 'ngSanitize', 'ngFileUpload']);

appProduto.config(['$routeProvider', function ($routeProvider, $routeParams) {
        $routeProvider
                .when('/produto', {
                    templateUrl: 'paginas/produto/index.html',
                })
                .when('/produto/novo', {
                    templateUrl: 'paginas/produto/novo.html',
                })
                .when('/produto/editar/:id', {
                    templateUrl: 'paginas/produto/novo.html',
                });
    }]);

appProduto.directive('fileModel', ['$parse', function ($parse) {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                var model = $parse(attrs.fileModel);
                var modelSetter = model.assign;

                element.bind('change', function () {
                    scope.$apply(function () {
                        modelSetter(scope, element[0].files[0]);
                    });
                });
            }
        };
    }]);


appProduto.service('fileUpload', ['$http', function ($http) {
        this.uploadFileToUrl = function (file, uploadUrl) {
            var fd = new FormData();
            fd.append('file', file);

            return $http.post(uploadUrl, fd, {
                transformRequest: angular.identity,
                headers: {'Content-Type': undefined}
            })

                    .success(function (data) {
                        return data.arquivosalvo;
                    })

                    .error(function () {

                    });
        }
    }]);

appProduto.controller('ProdutoController', ['$scope', '$location', '$http', 'ConfigFactory', function ($scope, $location, $http, ConfigFactory) {
        $scope.carregado = "hidden";
        $scope.classePermissao = ConfigFactory.getClasse();

        $scope.pagina = 1;
        $scope.tamanho = 20;
        $scope.total = 0;
        $scope.paginacao = [];
        $scope.blocopaginacao = 1;

        $scope.trocaBloco = function (pagina) {
            $scope.blocopaginacao += pagina;
            if ($scope.blocopaginacao < 1)
                $scope.blocopaginacao = 1;
            if ($scope.blocopaginacao > Math.ceil($scope.total / 10))
                $scope.blocopaginacao = Math.ceil($scope.total / 10);
            $scope.pagina = ($scope.blocopaginacao - 1) * 10 + 1;
            $scope.atualizar();
        }

        $scope.trocaPagina = function (pagina) {
            $scope.pagina = pagina;
            $scope.atualizar();
        }


        $scope.atualizar = function () {
            $http({
                method: 'GET',
                timeout: 10000,
                url: ConfigFactory.getUrl() + '/produto?pagina='+$scope.pagina+'&tamanho='+$scope.tamanho,
                headers: {
                    'Content-Type': 'application/json;charset=ISO-8859-1',
                }
            }).then(function successCallback(response) {
                        $scope.listagem = response.data.dados;
                        $scope.total = response.data.paginacao.total;
                        $scope.paginacao = [];
                        var i;
                        var indice = 0;
                        var inicio = ($scope.blocopaginacao-1) * 10 + 1 ;
                        var fim = inicio + 9;
                        if(fim>$scope.total) fim = $scope.total;
                        
                        
                        
                        
                        for(i=inicio;i<=fim;i++){
                           $scope.paginacao[indice] = i;
                           indice++;
                        }
                $scope.carregado = "display";
            }, function errorCallback(response) {
                console.log("erro");
            });
        }

        $scope.deletar = function (id) {

            swal({
                title: "Confirmação",
                text: "Tem certeza que deseja excluir este produto?",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "SIM",
                closeOnConfirm: true
            },
            function () {
                $http({
                    method: 'DELETE',
                    timeout: 10000,
                    url: ConfigFactory.getUrl() + '/produto/' + id,
                    headers: {
                        'Content-Type': 'application/json;charset=ISO-8859-1',
                    }
                }).then(function successCallback(response) {
                    toastr.success(response.data.descricao, 'Sucesso')
                    $scope.atualizar();
                }, function errorCallback(response) {

                });
            });

        };
        $scope.atualizar();

    }]);


appProduto.controller('ProdutoFormController', ['$scope', '$location', '$http', '$routeParams', 'ConfigFactory', 'ModalService', 'fileUpload', function ($scope, $location, $http, $routeParams, ConfigFactory, ModalService, fileUpload) {

                $scope.pagina = 1;
                $scope.tamanho = 20;
                $scope.total = 0;
                $scope.paginacao = [];   
                $scope.blocopaginacao = 1;
                $scope.blocoativo = 0;

                $scope.trocaBloco = function(pagina){
                    $scope.blocopaginacao+=pagina;
                    if($scope.blocopaginacao<1) $scope.blocopaginacao=1;
                    if($scope.blocopaginacao>Math.ceil($scope.total / 10) ) $scope.blocopaginacao=Math.ceil($scope.total / 10);
                    $scope.pagina = ($scope.blocopaginacao-1) * 10 + 1;
                    
                    if($scope.blocoativo==1) $scope.buscarMedidaProduto($routeParams.id);
                    if($scope.blocoativo==3) $scope.buscarAplicacao($routeParams.id);
                }

                $scope.trocaPagina = function(pagina){
                    $scope.pagina = pagina;
                    if($scope.blocoativo==1) $scope.buscarMedidaProduto($routeParams.id);
                    if($scope.blocoativo==3) $scope.buscarAplicacao($routeParams.id);
                }

        $scope.novaaplicacao = function (idProduto, idAplicacao) {
            if(!idAplicacao){
               var titulo = "Adicionar nova Aplicação";
            }
            else{
               var titulo = "Editar Aplicação"; 
            }
            ModalService.showModal({
                templateUrl: "paginas/produto/modal.html",
                controller: "ProdutoAplicacaoController",
                inputs: {
                    title: titulo,
                    idProduto: idProduto,
                    idAplicacao: idAplicacao,
                }
            }).then(function (modal) {
                modal.element.modal();
                modal.close.then(function (result) {
                    $scope.buscarAplicacao(idProduto);

                });
            });
        };

        $scope.novoConcorrente = function (idProduto, idConcorrente) {
            ModalService.showModal({
                templateUrl: "paginas/produto/modalconcorrente.html",
                controller: "ConcorrenteModalController",
                inputs: {
                    title: "Adicionar novo Concorrente",
                    idProduto: idProduto,
                    idConcorrente: idConcorrente,
                }
            }).then(function (modal) {
                modal.element.modal();
                modal.close.then(function (result) {
                    $scope.buscarConcorrente(idProduto);

                });
            });
        };

        $scope.novaMedidaProduto = function (idProduto, idMedidaProduto) {
            ModalService.showModal({
                templateUrl: "paginas/produto/modalmedidas.html",
                controller: "MedidaProdutoController",
                inputs: {
                    title: "Adicionar nova Medida por Produto",
                    idProduto: idProduto,
                    idMedidaProduto: idMedidaProduto,
                }
            }).then(function (modal) {
                modal.element.modal();
                modal.close.then(function (result) {
                    $scope.buscarMedidaProduto(idProduto);

                });
            });
        };

        $scope.buscar = function (id) {
            $http({
                method: 'GET',
                timeout: 10000,
                url: ConfigFactory.getUrl() + '/produto/' + id,
                headers: {
                    'Content-Type': 'application/json;charset=ISO-8859-1',
                }
            }).then(function successCallback(response) {
                $scope.produto = response.data;
                $scope.caminhoimagem = ConfigFactory.getUrl() + '/upload/';

            }, function errorCallback(response) {

            });

        };

        $scope.buscarAplicacao = function (id) {
            //Buscar a lista de aplicações deste produto
            if($scope.blocoativo!=3){
                 $scope.pagina = 1;
                $scope.tamanho = 20;
                $scope.total = 0;
                $scope.paginacao = [];   
                $scope.blocopaginacao = 1;               
            }
            
            $scope.blocoativo = 3;
            $http({
                method: 'GET',
                timeout: 10000,
                url: ConfigFactory.getUrl() + '/aplicacao/produto/' + id + '?pagina='+$scope.pagina+'&tamanho='+$scope.tamanho,
                headers: {
                    'Content-Type': 'application/json;charset=ISO-8859-1',
                }
            }).then(function successCallback(response) {
                $scope.aplicacoes = response.data.dados;
                    $scope.total = response.data.paginacao.total;
                        $scope.paginacao = [];
                        var i;
                        var indice = 0;
                        var inicio = ($scope.blocopaginacao-1) * 10 + 1 ;
                        var fim = inicio + 9;
                        if(fim>$scope.total) fim = $scope.total;
                        
                        
                        
                        
                        for(i=inicio;i<=fim;i++){
                           $scope.paginacao[indice] = i;
                           indice++;
                        }                

            }, function errorCallback(response) {

            });
        };

        $scope.buscarConcorrente = function (id) {
            //Buscar a lista de aplicações deste produto

            $http({
                method: 'GET',
                timeout: 10000,
                url: ConfigFactory.getUrl() + '/concorrente/produto/' + id,
                headers: {
                    'Content-Type': 'application/json;charset=ISO-8859-1',
                }
            }).then(function successCallback(response) {
                $scope.concorrentes = response.data;

            }, function errorCallback(response) {

            });
        };



        $scope.buscarMedidaProduto = function (id) {
            //Buscar a lista de aplicações deste produto
            if($scope.blocoativo!=1){
                $scope.pagina = 1;
                $scope.tamanho = 20;
                $scope.total = 0;
                $scope.paginacao = [];   
                $scope.blocopaginacao = 1;               
            }            
            
            $scope.blocoativo = 1;
            $http({
                method: 'GET',
                timeout: 10000,
                url: ConfigFactory.getUrl() + '/medidaproduto/produto/' + id + '?pagina='+$scope.pagina+'&tamanho='+$scope.tamanho,
                headers: {
                    'Content-Type': 'application/json;charset=ISO-8859-1',
                }
            }).then(function successCallback(response) {
                $scope.medidasproduto = response.data.dados;
                    $scope.total = response.data.paginacao.total;
                        $scope.paginacao = [];
                        var i;
                        var indice = 0;
                        var inicio = ($scope.blocopaginacao-1) * 10 + 1 ;
                        var fim = inicio + 9;
                        if(fim>$scope.total) fim = $scope.total;
                        
                        
                        
                        
                        for(i=inicio;i<=fim;i++){
                           $scope.paginacao[indice] = i;
                           indice++;
                        }
                    
                
                

            }, function errorCallback(response) {

            });
        };

        $scope.deletarAplicacao = function (idAplicacao, idProduto) {

            swal({
                title: "Confirmação",
                text: "Tem certeza que deseja excluir esta aplicação?",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "SIM",
                closeOnConfirm: true
            },
            function () {
                $http({
                    method: 'DELETE',
                    timeout: 10000,
                    url: ConfigFactory.getUrl() + '/aplicacao/' + idAplicacao,
                    headers: {
                        'Content-Type': 'application/json;charset=ISO-8859-1',
                    }
                }).then(function successCallback(response) {
                    toastr.success(response.data.descricao, 'Sucesso')
                    $scope.buscarAplicacao(idProduto);
                }, function errorCallback(response) {
                    toastr.error('Erro ao excluir aplicação', 'Erro')
                });
            });
        };

        $scope.deletarConcorrente = function (idConcorrente, idProduto) {

            swal({
                title: "Confirmação",
                text: "Tem certeza que deseja excluir este produto concorrente?",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "SIM",
                closeOnConfirm: true
            },
            function () {
                $http({
                    method: 'DELETE',
                    timeout: 10000,
                    url: ConfigFactory.getUrl() + '/concorrente/' + idConcorrente,
                    headers: {
                        'Content-Type': 'application/json;charset=ISO-8859-1',
                    }
                }).then(function successCallback(response) {
                    toastr.success(response.data.descricao, 'Sucesso')
                    $scope.buscarConcorrente(idProduto);
                }, function errorCallback(response) {
                    toastr.error('Erro ao excluir produto concorrente', 'Erro')
                });
            });
        };

        $scope.deletarMedidaProduto = function (idConcorrente, idProduto) {

            swal({
                title: "Confirmação",
                text: "Tem certeza que deseja excluir esta atribuição de medida ao produto?",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "SIM",
                closeOnConfirm: true
            },
            function () {
                $http({
                    method: 'DELETE',
                    timeout: 10000,
                    url: ConfigFactory.getUrl() + '/medidaproduto/' + idConcorrente,
                    headers: {
                        'Content-Type': 'application/json;charset=ISO-8859-1',
                    }
                }).then(function successCallback(response) {
                    toastr.success(response.data.descricao, 'Sucesso')
                    $scope.buscarMedidaProduto(idProduto);
                }, function errorCallback(response) {
                    toastr.error('Erro ao excluir medida do produto', 'Erro')
                });
            });
        };




        $scope.cadastrar = function (dados) {


            var file = $scope.myFile;
            
            if(file){
                var uploadUrl = ConfigFactory.getUrl() + "/upload";

                var arquivosubido = fileUpload.uploadFileToUrl(file, uploadUrl);
                arquivosubido.then(function (dadosretorno) {
                    dados.imagem = dadosretorno.data.arquivosalvo;

                    var metodo = "POST";
                    if (dados.id)
                        metodo = "PUT";

                    $http({
                        method: metodo,
                        timeout: 10000,
                        url: ConfigFactory.getUrl() + '/produto',
                        headers: {
                            'Content-Type': 'application/json;charset=ISO-8859-1',
                        },
                        data: dados
                    }).then(function successCallback(response) {
                        toastr.success(response.data.descricao, 'Sucesso')
                        $location.path('/produto');
                    }, function errorCallback(response) {

                    });


                });                
            }   
            else{
                    var metodo = "POST";
                    if (dados.id)
                        metodo = "PUT";

                    $http({
                        method: metodo,
                        timeout: 10000,
                        url: ConfigFactory.getUrl() + '/produto',
                        headers: {
                            'Content-Type': 'application/json;charset=ISO-8859-1',
                        },
                        data: dados
                    }).then(function successCallback(response) {
                        toastr.success(response.data.descricao, 'Sucesso')
                        $location.path('/produto');
                    }, function errorCallback(response) {

                    });                
            }
        };


        $scope.geracombos = function () {
            //Buscar as montadoras
            $http({
                method: 'GET',
                timeout: 10000,
                url: ConfigFactory.getUrl() + '/medida/',
                headers: {
                    'Content-Type': 'application/json;charset=ISO-8859-1',
                }
            }).then(function successCallback(response) {
                $scope.medidas = response.data;

            }, function errorCallback(response) {

            });

        }

        if ($routeParams.id) {
            $scope.buscar($routeParams.id);
            //$scope.buscarAplicacao($routeParams.id);
            //$scope.buscarConcorrente($routeParams.id);
            //$scope.buscarMedidaProduto($routeParams.id);
            $scope.titulo = "Editar Produto";
            $scope.ocultarabas = "display";
        }
        else {
            $scope.titulo = "Novo Produto";

            $scope.ocultarabas = "hidden";
        }

        $scope.geracombos();


    }]);


appProduto.controller('ProdutoAplicacaoController', ['$scope', '$http', '$element', 'title', 'idProduto', 'idAplicacao', 'close', 'ConfigFactory', function ($scope, $http, $element, title, idProduto, idAplicacao, close, ConfigFactory) {

        $scope.name = null;
        $scope.age = null;
        $scope.title = title;
        $scope.idProduto = idProduto;
        $scope.idAplicacao = idAplicacao;
        $scope.aplicacao = {produto: {id: idProduto}};
        $scope.versaoselecionada = {};

        $scope.homologados = [
            {id: "SIM", descricao: "SIM"},
            {id: "NÃO", descricao: "NÃO"},
        ];

        
        
                $scope.trocamontadora = function(busca){
                    console.log("Troca montadora");
                    $scope.versoes = null;
                    $scope.anos = null;
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/modelo/montadora/'+busca+'?pagina=1&tamanho=1000',
                        headers: {
                            'Content-Type': 'application/json',
                        }
                    }).then(function successCallback(response) {
                        $scope.modelos = response.data.dados;
                        //console.log(response.data);
                    }, function errorCallback(response) {
                        console.log("erro");
                    });     
                    $scope.buscaCriterio(busca);
                }           
        
        
        
        $scope.getMedidas = function () {

            $http({
                method: "GET",
                timeout: 10000,
                url: ConfigFactory.getUrl() + '/medida?pagina=1&tamanho=99999',
                headers: {
                    'Content-Type': 'application/json;charset=ISO-8859-1',
                }
            }).then(function successCallback(response) {
                //console.log(response.data.dados);
                $scope.medidas = response.data.dados;
            }, function errorCallback(response) {

            });
        };        
        
        $scope.getMarcas= function () {

            $http({
                method: "GET",
                timeout: 10000,
                url: ConfigFactory.getUrl() + '/montadora?pagina=1&tamanho=99999',
                headers: {
                    'Content-Type': 'application/json;charset=ISO-8859-1',
                }
            }).then(function successCallback(response) {
                //console.log(response.data.dados);
                $scope.marcas = response.data.dados;
            }, function errorCallback(response) {

            });
        };          
        
        $scope.getModelos= function () {

            $http({
                method: "GET",
                timeout: 10000,
                url: ConfigFactory.getUrl() + '/modelo?pagina=1&tamanho=99999',
                headers: {
                    'Content-Type': 'application/json;charset=ISO-8859-1',
                }
            }).then(function successCallback(response) {
                //console.log(response.data.dados);
                $scope.modelos = response.data.dados;
            }, function errorCallback(response) {

            });
        };          
                
        
        
        /*
        $scope.getVersoes = function () {

            $http({
                method: "GET",
                timeout: 10000,
                url: ConfigFactory.getUrl() + '/versao/',
                headers: {
                    'Content-Type': 'application/json;charset=ISO-8859-1',
                }
            }).then(function successCallback(response) {
                console.log(response.data);
                $scope.versoes = response.data;
            }, function errorCallback(response) {

            });
        };
        */
        

        $scope.getAplicacao = function (id) {
            $http({
                method: "GET",
                timeout: 10000,
                url: ConfigFactory.getUrl() + '/aplicacao/' + id,
                headers: {
                    'Content-Type': 'application/json;charset=ISO-8859-1',
                }
            }).then(function successCallback(response) {
                $scope.aplicacao = response.data;
                
                $scope.trocamontadora($scope.aplicacao.modelo.montadora.id);
                
            }, function errorCallback(response) {

            });
        };

        //  This close function doesn't need to use jQuery or bootstrap, because
        //  the button has the 'data-dismiss' attribute.
        $scope.close = function (aplicacao) {

            console.log("Vou Gravar");
            console.log(aplicacao);
            var method = "POST";
            if ($scope.idAplicacao != null)
                method = "PUT";

            $http({
                method: method,
                url: ConfigFactory.getUrl() + '/aplicacao',
                headers: {
                    'Content-Type': 'application/json;charset=ISO-8859-1',
                },
                data: aplicacao
            }).then(function successCallback(response) {
                toastr.success(response.data.descricao, 'Sucesso')
            }, function errorCallback(response) {

            });

            close({
                name: $scope.name,
                age: $scope.age
            }, 500); // close, but give 500ms for bootstrap to animate
        };



        //  This cancel function must use the bootstrap, 'modal' function because
        //  the doesn't have the 'data-dismiss' attribute.
        $scope.cancel = function () {

            //  Manually hide the modal.
            $element.modal('hide');

            //  Now call close, returning control to the caller.
            close({
                name: $scope.name,
                age: $scope.age
            }, 500); // close, but give 500ms for bootstrap to animate
        };

        if (idAplicacao != null)
            $scope.getAplicacao(idAplicacao);
        $scope.getMedidas();
        $scope.getMarcas();
        //$scope.getModelos();

    }]);



appProduto.controller('ConcorrenteModalController', ['$scope', '$http', '$element', 'title', 'idProduto', 'idConcorrente', 'close', 'ConfigFactory', function ($scope, $http, $element, title, idProduto, idConcorrente, close, ConfigFactory) {

        console.log("Concorrente Controller");
        $scope.title = title;
        $scope.idProduto = idProduto;
        $scope.idConcorrente = idConcorrente;
        $scope.concorrente = {produto: {id: idProduto}};
        $scope.versaoselecionada = {};




        //  This close function doesn't need to use jQuery or bootstrap, because
        //  the button has the 'data-dismiss' attribute.
        $scope.close = function (concorrente) {

            console.log("Vou Gravar");
            console.log(concorrente);
            var method = "POST";
            if ($scope.idConcorrente != null)
                method = "PUT";

            $http({
                method: method,
                timeout: 10000,
                url: ConfigFactory.getUrl() + '/concorrente',
                headers: {
                    'Content-Type': 'application/json;charset=ISO-8859-1',
                },
                data: concorrente
            }).then(function successCallback(response) {
                toastr.success(response.data.descricao, 'Sucesso')
            }, function errorCallback(response) {

            });

            close({}, 500); // close, but give 500ms for bootstrap to animate
        };
        
        $scope.getFabricantes = function () {
            console.log("Lendo fabricantes");
            $http({
                method: "GET",
                timeout: 10000,
                url: ConfigFactory.getUrl() + '/fabricante'+'?pagina=1&tamanho=99999',
                headers: {
                    'Content-Type': 'application/json;charset=ISO-8859-1',
                }
            }).then(function successCallback(response) {
                $scope.fabricantes = response.data.dados;
            }, function errorCallback(response) {

            });
        };
        
        

        $scope.getConcorrente = function (id) {
            $http({
                method: "GET",
                timeout: 10000,
                url: ConfigFactory.getUrl() + '/concorrente/' + id,
                headers: {
                    'Content-Type': 'application/json;charset=ISO-8859-1',
                }
            }).then(function successCallback(response) {
                $scope.concorrente = response.data;
            }, function errorCallback(response) {

            });
        };

        $scope.getMedidaProduto = function (id) {
            $http({
                method: "GET",
                timeout: 10000,
                url: ConfigFactory.getUrl() + '/medidaproduto/' + id,
                headers: {
                    'Content-Type': 'application/json;charset=ISO-8859-1',
                }
            }).then(function successCallback(response) {
                $scope.medidaproduto = response.data;
            }, function errorCallback(response) {

            });
        };


        //  This cancel function must use the bootstrap, 'modal' function because
        //  the doesn't have the 'data-dismiss' attribute.
        $scope.cancel = function () {

            //  Manually hide the modal.
            $element.modal('hide');

            //  Now call close, returning control to the caller.
            close({}, 500); // close, but give 500ms for bootstrap to animate
        };

        if (idConcorrente != null) $scope.getConcorrente(idConcorrente);
        $scope.getFabricantes();

    }]);

appProduto.controller('MedidaProdutoController', ['$scope', '$http', '$element', 'title', 'idProduto', 'idMedidaProduto', 'close', 'ConfigFactory', function ($scope, $http, $element, title, idProduto, idMedidaProduto, close, ConfigFactory) {


        $scope.title = title;
        $scope.idProduto = idProduto;
        $scope.idMedidaProduto = idMedidaProduto;
        $scope.medidaproduto = {produto: {id: idProduto}, medida: {id: ''}};
        $scope.versaoselecionada = {};




        //  This close function doesn't need to use jQuery or bootstrap, because
        //  the button has the 'data-dismiss' attribute.
        $scope.close = function (medidaproduto) {

            console.log("Vou Gravar");
            console.log(medidaproduto);
            var method = "POST";
            if ($scope.idMedidaProduto != null)
                method = "PUT";

            $http({
                method: method,
                timeout: 10000,
                url: ConfigFactory.getUrl() + '/medidaproduto',
                headers: {
                    'Content-Type': 'application/json;charset=ISO-8859-1',
                },
                data: medidaproduto
            }).then(function successCallback(response) {
                toastr.success(response.data.descricao, 'Sucesso')
            }, function errorCallback(response) {

            });

            close({}, 500); // close, but give 500ms for bootstrap to animate
        };

        $scope.getMedidaProduto = function (id) {
            $http({
                method: "GET",
                timeout: 10000,
                url: ConfigFactory.getUrl() + '/medidaproduto/' + id,
                headers: {
                    'Content-Type': 'application/json;charset=ISO-8859-1',
                }
            }).then(function successCallback(response) {
                $scope.medidaproduto = response.data;
            }, function errorCallback(response) {

            });
        };

        $scope.getMedidas = function () {

            $http({
                method: "GET",
                timeout: 10000,
                url: ConfigFactory.getUrl() + '/medida?pagina=1&tamanho=1000',
                headers: {
                    'Content-Type': 'application/json;charset=ISO-8859-1',
                }
            }).then(function successCallback(response) {
                $scope.medidas = response.data.dados;
            }, function errorCallback(response) {

            });
        };



        //  This cancel function must use the bootstrap, 'modal' function because
        //  the doesn't have the 'data-dismiss' attribute.
        $scope.cancel = function () {

            //  Manually hide the modal.
            $element.modal('hide');

            //  Now call close, returning control to the caller.
            close({}, 500); // close, but give 500ms for bootstrap to animate
        };

        if (idMedidaProduto != null) $scope.getMedidaProduto(idMedidaProduto);
        $scope.getMedidas();

    }]);





