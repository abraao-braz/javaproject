'use strict';

angular.module('PirelliApp.login', ['ngRoute'])

        .config(['$routeProvider', function ($routeProvider) {
                $routeProvider.when('/login', {
                    templateUrl: 'paginas/login/login.html',
                    controller: 'LoginController'
                });
            }])

        .controller('LoginController', ['$scope', '$location', '$http', 'ConfigFactory', function ($scope, $location, $http, ConfigFactory) {
                $scope.login = function (usuario) {
                    $http({
                        method: 'POST',
                        url: ConfigFactory.getUrl() + '/usuario/login',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        data: usuario
                    }).then(function successCallback(response) {
                        
                        ConfigFactory.setLogado(true);
                        

                        if(response.data.tipo=="1"||response.data.tipo=="2"){
                            ConfigFactory.setLogado(true);
                            ConfigFactory.setTipo(response.data.tipo);
                            localStorage.setItem("pirelli.tipo", response.data.tipo);
                            
                            $location.path("/selecao");
                        }
                        else {
                            toastr.error(response.data.descricao, 'Erro')
                            ConfigFactory.setLogado(false);
                        }
                        
                    }, function errorCallback(response) {
                        console.log("erro");
                    });



                };
            }]);