'use strict';
var appConcorrente = angular.module('PirelliApp.concorrente', ['ngRoute', 'angular-loading-bar', 'PirelliApp.configuracoes', 'angularModalService', 'ui.select', 'ngSanitize', 'ngFileUpload']);

appConcorrente.config(['$routeProvider', function ($routeProvider, $routeParams) {
        $routeProvider
                .when('/concorrentes', {
                    templateUrl: 'paginas/concorrente/index.html',
                })
                .when('/concorrente/novo', {
                    templateUrl: 'paginas/concorrente/novo.html',
                })
                .when('/concorrente/editar/:id', {
                    templateUrl: 'paginas/concorrente/novo.html',
                });
    }]);

appConcorrente.directive('fileModel', ['$parse', function ($parse) {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                var model = $parse(attrs.fileModel);
                var modelSetter = model.assign;

                element.bind('change', function () {
                    scope.$apply(function () {
                        modelSetter(scope, element[0].files[0]);
                    });
                });
            }
        };
    }]);


appConcorrente.service('fileUpload', ['$http', function ($http) {
        this.uploadFileToUrl = function (file, uploadUrl) {
            var fd = new FormData();
            fd.append('file', file);

            return $http.post(uploadUrl, fd, {
                transformRequest: angular.identity,
                headers: {'Content-Type': undefined}
            })

                    .success(function (data) {
                        return data.arquivosalvo;
                    })

                    .error(function () {

                    });
        }
    }]);

appConcorrente.controller('ConcorrenteController', ['$scope', '$location', '$http', 'ConfigFactory', function ($scope, $location, $http, ConfigFactory) {
        $scope.carregado = "hidden";
        $scope.classePermissao = ConfigFactory.getClasse();

        $scope.pagina = 1;
        $scope.tamanho = 20;
        $scope.total = 0;
        $scope.paginacao = [];
        $scope.blocopaginacao = 1;

        $scope.trocaBloco = function (pagina) {
            $scope.blocopaginacao += pagina;
            if ($scope.blocopaginacao < 1)
                $scope.blocopaginacao = 1;
            if ($scope.blocopaginacao > Math.ceil($scope.total / 10))
                $scope.blocopaginacao = Math.ceil($scope.total / 10);
            $scope.pagina = ($scope.blocopaginacao - 1) * 10 + 1;
            $scope.atualizar();
        }

        $scope.trocaPagina = function (pagina) {
            $scope.pagina = pagina;
            $scope.atualizar();
        }


        $scope.atualizar = function () {
            $http({
                method: 'GET',
                timeout: 10000,
                url: ConfigFactory.getUrl() + '/fabricante?pagina=' + $scope.pagina + '&tamanho=' + $scope.tamanho,
                headers: {
                    'Content-Type': 'application/json;charset=ISO-8859-1',
                }
            }).then(function successCallback(response) {
                $scope.listagem = response.data.dados;
                $scope.total = response.data.paginacao.total;
                $scope.paginacao = [];
                var i;
                var indice = 0;
                var inicio = ($scope.blocopaginacao - 1) * 10 + 1;
                var fim = inicio + 9;
                if (fim > $scope.total)
                    fim = $scope.total;




                for (i = inicio; i <= fim; i++) {
                    $scope.paginacao[indice] = i;
                    indice++;
                }
                $scope.carregado = "display";
            }, function errorCallback(response) {
                console.log("erro");
            });
        }

        $scope.deletar = function (id) {

            swal({
                title: "Confirmação",
                text: "Tem certeza que deseja excluir este concorrente?",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "SIM",
                closeOnConfirm: true
            },
            function () {
                $http({
                    method: 'DELETE',
                    timeout: 10000,
                    url: ConfigFactory.getUrl() + '/fabricante/' + id,
                    headers: {
                        'Content-Type': 'application/json;charset=ISO-8859-1',
                    }
                }).then(function successCallback(response) {
                    toastr.success(response.data.descricao, 'Sucesso')
                    $scope.atualizar();
                }, function errorCallback(response) {

                });
            });

        };
        $scope.atualizar();

    }]);


appConcorrente.controller('ConcorrenteFormController', ['$scope', '$location', '$http', '$routeParams', 'ConfigFactory', 'ModalService', 'fileUpload', function ($scope, $location, $http, $routeParams, ConfigFactory, ModalService, fileUpload) {

        $scope.pagina = 1;
        $scope.tamanho = 20;
        $scope.total = 0;
        $scope.paginacao = [];
        $scope.blocopaginacao = 1;
        $scope.blocoativo = 0;

        $scope.trocaBloco = function (pagina) {
            $scope.blocopaginacao += pagina;
            if ($scope.blocopaginacao < 1)
                $scope.blocopaginacao = 1;
            if ($scope.blocopaginacao > Math.ceil($scope.total / 10))
                $scope.blocopaginacao = Math.ceil($scope.total / 10);
            $scope.pagina = ($scope.blocopaginacao - 1) * 10 + 1;

            //if($scope.blocoativo==1) $scope.buscarMedidaConcorrente($routeParams.id);
            //if($scope.blocoativo==3) $scope.buscarAplicacao($routeParams.id);
        }

        $scope.trocaPagina = function (pagina) {
            $scope.pagina = pagina;
            if ($scope.blocoativo == 1)
                $scope.buscarMedidaConcorrente($routeParams.id);
            if ($scope.blocoativo == 3)
                $scope.buscarAplicacao($routeParams.id);
        }




        $scope.buscar = function (id) {
            $http({
                method: 'GET',
                timeout: 10000,
                url: ConfigFactory.getUrl() + '/fabricante/' + id,
                headers: {
                    'Content-Type': 'application/json;charset=ISO-8859-1',
                }
            }).then(function successCallback(response) {
                $scope.concorrente = response.data;
                $scope.caminhoimagem = ConfigFactory.getUrl() + '/upload/';

            }, function errorCallback(response) {

            });

        };





        $scope.cadastrar = function (dados) {

            var metodo = "POST";
            if (dados.id)
                metodo = "PUT";
            var file = $scope.myFile;

            var uploadUrl = ConfigFactory.getUrl() + "/upload";

            if (file) {
                var arquivosubido = fileUpload.uploadFileToUrl(file, uploadUrl);

                arquivosubido.then(function (dadosretorno) {
                    dados.imagem = dadosretorno.data.arquivosalvo;



                    $http({
                        method: metodo,
                        timeout: 10000,
                        url: ConfigFactory.getUrl() + '/fabricante',
                        headers: {
                            'Content-Type': 'application/json;charset=ISO-8859-1',
                        },
                        data: dados
                    }).then(function successCallback(response) {
                        toastr.success(response.data.descricao, 'Sucesso')
                        $location.path('/concorrentes');
                    }, function errorCallback(response) {

                    });


                });
            }
            else {
                $http({
                    method: metodo,
                    timeout: 10000,
                    url: ConfigFactory.getUrl() + '/fabricante',
                    headers: {
                        'Content-Type': 'application/json;charset=ISO-8859-1',
                    },
                    data: dados
                }).then(function successCallback(response) {
                    toastr.success(response.data.descricao, 'Sucesso')
                    $location.path('/concorrentes');
                }, function errorCallback(response) {

                });
            }








        };



        if ($routeParams.id) {
            $scope.buscar($routeParams.id);
            //$scope.buscarAplicacao($routeParams.id);
            //$scope.buscarConcorrente($routeParams.id);
            //$scope.buscarMedidaConcorrente($routeParams.id);
            $scope.titulo = "Editar Concorrente";
            $scope.ocultarabas = "display";
        }
        else {
            $scope.titulo = "Novo Concorrente";

            $scope.ocultarabas = "hidden";
        }

        //$scope.geracombos();


    }]);