'use strict';

angular.module('PirelliApp.detalheproduto', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/detalheprodutomedida/:id/:idmedida', {
    templateUrl: 'paginas/detalhe_produto/produtomodelo.html',
    controller: 'ProdutoController2'
  });
  
  $routeProvider.when('/detalheproduto/:id/:idmodelo/:idmedida', {
    templateUrl: 'paginas/detalhe_produto/produto.html',
    controller: 'ProdutoController2'
  });  
  
  
}])

.controller('ProdutoController2',['$scope', '$location', '$http', '$routeParams', 'ConfigFactory','ModalService', function ($scope, $location, $http, $routeParams, ConfigFactory, ModalService) {
    console.log("Detalhe do produto: "+ $routeParams.id);
    $scope.classePermissao = ConfigFactory.getClasse();
    $scope.caminhoimagem = ConfigFactory.getUrl() + '/upload/';
    
    $scope.modelo = $routeParams.idmodelo;
    $scope.medidafiltro = $routeParams.idmedida;
    
    $scope.buscaProduto = function (id) {
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/produto/'+id,
                        headers: {
                            'Content-Type': 'application/json',
                        }
                    }).then(function successCallback(response) {
                        $scope.produto = response.data;
                        console.log(response.data);
                    }, function errorCallback(response) {
                        console.log("erro");
                    });
    };  
    
    $scope.buscaMedidas = function (id){
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/medidaproduto/produtounica/'+id+'?pagina=1&tamanho=1000',
                        headers: {
                            'Content-Type': 'application/json',
                        }
                    }).then(function successCallback(response) {
                        $scope.medidasproduto = response.data.dados;
                        console.log("Medidas do Produto");
                        console.log(response.data);
                    }, function errorCallback(response) {
                        console.log("erro");
                    });        
    }
    
    $scope.buscaIp7 = function (id){
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/aplicacao/produto/'+id+"?pagina=1&tamanho=9999",
                        headers: {
                            'Content-Type': 'application/json',
                        }
                    }).then(function successCallback(response) {
                        console.log("ip7");
                        $scope.ip7produtos = response.data.dados;
                        console.log(response.data);
                    }, function errorCallback(response) {
                        console.log("erro");
                    });        
    }    
    
    $scope.buscaConcorrente = function (id){
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/concorrente/produto/'+id,
                        headers: {
                            'Content-Type': 'application/json',
                        }
                    }).then(function successCallback(response) {
                        $scope.concorrentes = response.data;
                    }, function errorCallback(response) {
                        console.log("erro");
                    });        
    }    
    
    
    
    $scope.buscaProduto($routeParams.id);
    $scope.buscaMedidas($routeParams.id);
    $scope.buscaIp7($routeParams.id);
    $scope.buscaConcorrente($routeParams.id);
    
    
}]);