'use strict';

angular.module('PirelliApp.tabelaequivalencia', ['ngRoute'])

        .config(['$routeProvider', function ($routeProvider) {
                $routeProvider.when('/tabelaequivalencia', {
                    templateUrl: 'paginas/tabelaequivalencia/tabelaequivalencia.html',
                    controller: 'TabelaEquivalenciaController'
                });
        }])

        .controller('TabelaEquivalenciaController', ['$scope', '$location', '$http', '$routeParams', 'ConfigFactory', function ($scope, $location, $http, $routeParams, ConfigFactory) {
                console.log("Tabela de equivalencia");
                $scope.eq = {
                    c5: "185",
                    e5: "60",
                    g5: "15",
                    c7: "185",
                    e7: "60",
                    g7: "15",                    
                }
        
        
        }]);