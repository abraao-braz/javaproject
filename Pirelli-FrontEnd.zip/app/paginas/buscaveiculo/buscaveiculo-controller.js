'use strict';

angular.module('PirelliApp.buscaveiculo', ['ngRoute'])

        .config(['$routeProvider', function ($routeProvider) {
                $routeProvider.when('/buscaveiculo', {
                    templateUrl: 'paginas/buscaveiculo/buscaveiculo.html',
                    controller: 'BuscaVeiculoController'
                });
            }])

        .controller('BuscaVeiculoController', ['$scope', '$location', '$http', 'ConfigFactory', function ($scope, $location, $http, ConfigFactory) {
                $scope.classeoculta = "hidden"; 
                $scope.classePermissao = ConfigFactory.getClasse();
                $scope.caminhoimagem = ConfigFactory.getUrl() + '/upload/';
                
                $scope.trocamontadora = function(busca){
                    $scope.versoes = null;
                    $scope.anos = null;
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/modelo/montadora/'+busca.montadora+'?pagina=1&tamanho=1000',
                        headers: {
                            'Content-Type': 'application/json',
                        }
                    }).then(function successCallback(response) {
                        $scope.modelos = response.data.dados;
                        //console.log(response.data);
                    }, function errorCallback(response) {
                        console.log("erro");
                    });     
                    $scope.buscaCriterio(busca);
                }    
                
                $scope.trocamodelo = function(busca){
                    $scope.versoes = null;
                    $scope.anos = null;
                    $scope.busca.versao = "undefined";
                    $scope.busca.ano = "undefined";
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/versao/modelounico/'+busca.modelo+'?pagina=1&tamanho=1000',
                        headers: {
                            'Content-Type': 'application/json',
                        }
                    }).then(function successCallback(response) {
                        $scope.versoes = response.data;
                        //console.log(response.data);
                    }, function errorCallback(response) {
                        console.log("erro");
                    });    
                    
                    $scope.buscaCriterio(busca);
                }
                
                $scope.trocaversao = function(busca){
                    console.log("trocando versao");
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/aplicacao/anos/'+busca.modelo+'/'+busca.versao,
                        headers: {
                            'Content-Type': 'application/json',
                        }
                    }).then(function successCallback(response) {
                        $scope.anos = response.data;
                        //console.log(response.data);
                    }, function errorCallback(response) {
                        console.log("erro");
                    }); 
                    
                    $scope.buscaCriterio(busca);
                }
                
                $scope.trocaano = function(busca){
                    $scope.buscaCriterio(busca);
                }
                
                $scope.buscaCriterio = function(busca){
                    
                    
                    
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/busca/medida/'+busca.modelo+'/'+busca.versao+'/'+busca.ano,
                        headers: {
                            'Content-Type': 'application/json',
                        }
                    }).then(function successCallback(response) {
                        $scope.produtos = response.data;
                        $scope.qt_homologados = 0;
                        $scope.qt_naohomologados = 0;
                        var i;
                        for(i=0;i<$scope.produtos.length;i++){
                            if($scope.produtos[i].homologado=='SIM') $scope.qt_homologados++;
                            else $scope.qt_naohomologados++;
                            
                        }
                        
                        
                        if(response.data.length>0){
                          $scope.classeoculta = "display";
                        }
                        else{
                           $scope.classeoculta = "hidden"; 
                        }
                    }, function errorCallback(response) {
                        $scope.classeoculta = "hidden"; 
                    });                     
                }
                
                        
                $scope.buscaProdutos = function () {
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/produto',
                        headers: {
                            'Content-Type': 'application/json',
                        }
                    }).then(function successCallback(response) {
                        $scope.produtos = response.data;
                        console.log(response.data);
                    }, function errorCallback(response) {
                        console.log("erro");
                    });
                };

                $scope.buscaMontadoras = function () {
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/montadora?pagina=1&tamanho=1000',
                        headers: {
                            'Content-Type': 'application/json',
                        }
                    }).then(function successCallback(response) {
                        $scope.montadoras = response.data.dados;
                        console.log(response.data);
                    }, function errorCallback(response) {
                        console.log("erro");
                    });
                };

                $scope.buscaModelos = function () {
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/modelo',
                        headers: {
                            'Content-Type': 'application/json',
                        }
                    }).then(function successCallback(response) {
                        $scope.modelos = response.data;
                        console.log(response.data);
                    }, function errorCallback(response) {
                        console.log("erro");
                    });
                };

                $scope.buscaVersoes = function () {
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/versao',
                        headers: {
                            'Content-Type': 'application/json',
                        }
                    }).then(function successCallback(response) {
                        $scope.versoes = response.data;
                        console.log(response.data);
                    }, function errorCallback(response) {
                        console.log("erro");
                    });
                };

                $scope.buscaAplicacoes = function () {
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/aplicacao',
                        headers: {
                            'Content-Type': 'application/json',
                        }
                    }).then(function successCallback(response) {
                        $scope.aplicacoes = response.data;
                        console.log(response.data);
                    }, function errorCallback(response) {
                        console.log("erro");
                    });
                };




                //$scope.buscaProdutos();
                $scope.buscaMontadoras();
                //$scope.buscaModelos();
                //$scope.buscaVersoes();
                //$scope.buscaAplicacoes();

            }])

        .filter('unique', function () {

            return function (items, filterOn) {

                if (filterOn === false) {
                    return items;
                }

                if ((filterOn || angular.isUndefined(filterOn)) && angular.isArray(items)) {
                    var hashCheck = {}, newItems = [];

                    var extractValueToCompare = function (item) {
                        if (angular.isObject(item) && angular.isString(filterOn)) {
                            return item[filterOn];
                        } else {
                            return item;
                        }
                    };

                    angular.forEach(items, function (item) {
                        var valueToCheck, isDuplicate = false;

                        for (var i = 0; i < newItems.length; i++) {
                            if (angular.equals(extractValueToCompare(newItems[i]), extractValueToCompare(item))) {
                                isDuplicate = true;
                                break;
                            }
                        }
                        if (!isDuplicate) {
                            newItems.push(item);
                        }

                    });
                    items = newItems;
                }
                return items;
            };
        });

        