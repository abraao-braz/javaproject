'use strict';

angular.module('PirelliApp.buscamedida', ['ngRoute'])

        .config(['$routeProvider', function ($routeProvider) {
                $routeProvider.when('/buscamedida', {
                    templateUrl: 'paginas/buscamedida/buscamedida_medida.html',
                    controller: 'BuscaMedidaController'
                });
                
                $routeProvider.when('/buscamedida/:id', {
                    templateUrl: 'paginas/buscamedida/buscamedida.html',
                    controller: 'BuscaMedidaController'
                });
                
                $routeProvider.when('/buscamedida/:id/:idmodelo', {
                    templateUrl: 'paginas/buscamedida/buscamedida.html',
                    controller: 'BuscaMedidaController'
                });                
                
            }])

        .controller('BuscaMedidaController', ['$scope', '$location', '$http', '$routeParams', 'ConfigFactory', function ($scope, $location, $http, $routeParams, ConfigFactory) {
                //Busca as medidas
                $scope.classePermissao = ConfigFactory.getClasse();
                $scope.busca = {medida:$routeParams.id, carga: null};
                $scope.classeoculta = "hidden";
                $scope.caminhoimagem = ConfigFactory.getUrl() + '/upload/';
                $scope.modelobusca = $routeParams.idmodelo;
                
                
                
                
                $scope.buscaModelo = function (busca) {
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/modelo/'+busca,
                        headers: {
                            'Content-Type': 'application/json',
                        }
                    }).then(function successCallback(response) {
                        $scope.modelo = response.data;
                    }, function errorCallback(response) {
                        console.log("erro");
                    });
                };
                
                
                
                $scope.buscaCarga = function(busca){
                    $scope.busca.medida = busca.medida;
                    
                    var urlBusca = "";
                    if($scope.modelobusca){
                       urlBusca = ConfigFactory.getUrl() + '/medida/cargasmodelo/'+busca.medida+"/"+$scope.modelobusca; 
                    }
                    else{
                        urlBusca = ConfigFactory.getUrl() + '/medida/cargas/'+busca.medida;
                    }
                    
                    $http({
                        method: 'GET',
                        url: urlBusca,
                        headers: {
                            'Content-Type': 'application/json',
                        }
                    }).then(function successCallback(response) {
                        $scope.cargas = response.data;
                        $scope.buscaCriterio(busca);
                        /*
                        if(response.data.length>0){
                          $scope.classeoculta = "display";
                        }
                        else{
                           $scope.classeoculta = "hidden"; 
                        }
                        */
                     
                    }, function errorCallback(response) {
                        //$scope.classeoculta = "hidden";
                    });                    
                };
                
                
                $scope.buscaCriterio = function(busca){
                    $scope.busca.carga = busca.carga;
                    console.log($scope.busca);
                    
                    var modelo = "";
                    if($scope.modelobusca) modelo = $scope.modelobusca;
                    else modelo = "null";
                    
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/busca/'+busca.medida+"/"+busca.carga+"/"+modelo,
                        headers: {
                            'Content-Type': 'application/json',
                        }
                    }).then(function successCallback(response) {
                        $scope.produtos = response.data;                                                
                        
                        if(response.data.length>0){
                          $scope.classeoculta = "display";
                        }
                        else{
                           $scope.classeoculta = "hidden"; 
                        }
                        
                        $scope.qt_homologados = 0;
                        $scope.qt_naohomologados = 0;
                        var i;
                        for(i=0;i<$scope.produtos.length;i++){
                            if($scope.produtos[i].homologado=='SIM') $scope.qt_homologados++;
                            else $scope.qt_naohomologados++;
                            
                        }                        
                        
                     
                    }, function errorCallback(response) {
                        $scope.classeoculta = "hidden";
                    });
                }
        
        
                $scope.buscaMedidas = function () {
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/medida/vinculadas?pagina=1&tamanho=1000',
                        headers: {
                            'Content-Type': 'application/json',
                        }
                    }).then(function successCallback(response) {
                        $scope.medidas = response.data.dados;
                    }, function errorCallback(response) {
                        console.log("erro");
                    });
                            
                };
                
                $scope.buscaProdutos = function(){
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl() + '/produto',
                        headers: {
                            'Content-Type': 'application/json',
                        }
                    }).then(function successCallback(response) {
                        $scope.produtos = response.data;
                        console.log(response.data);
                    }, function errorCallback(response) {
                        console.log("erro");
                    });                    
                };
                
                
                $scope.buscaMedidas();
                $scope.buscaCarga($scope.busca);
                $scope.buscaCriterio($scope.busca);
                if($routeParams.idmodelo) $scope.buscaModelo($routeParams.idmodelo);
                
                
                //$scope.buscaProdutos();

            }]);