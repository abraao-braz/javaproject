'use strict';

angular.module('PirelliApp.marca', ['ngRoute', 'angular-loading-bar','PirelliApp.configuracoes'])
        
        .config(['$routeProvider', function ($routeProvider, $routeParams) {
                $routeProvider
                        .when('/marca', {
                            templateUrl: 'paginas/marca/index.html',
                        })
                        .when('/marca/novo', {
                            templateUrl: 'paginas/marca/novo.html',
                        })
                        .when('/marca/editar/:id', {
                            templateUrl: 'paginas/marca/novo.html',
                        })
                        
                        ;
            }])

        .controller('MarcaController', ['$scope', '$location', '$http', 'ConfigFactory', function ($scope, $location, $http,ConfigFactory) {
                $scope.carregado = "hidden";
                $scope.classePermissao = ConfigFactory.getClasse();
                $scope.pagina = 1;
                $scope.tamanho = 20;
                $scope.total = 0;
                $scope.paginacao = [];   
                $scope.blocopaginacao = 1;

                $scope.trocaBloco = function(pagina){
                    $scope.blocopaginacao+=pagina;
                    if($scope.blocopaginacao<1) $scope.blocopaginacao=1;
                    if($scope.blocopaginacao>Math.ceil($scope.total / 10) ) $scope.blocopaginacao=Math.ceil($scope.total / 10);
                    $scope.pagina = ($scope.blocopaginacao-1) * 10 + 1;
                    $scope.atualizar();
                }

                $scope.trocaPagina = function(pagina){
                    $scope.pagina = pagina;
                    $scope.atualizar();
                }
                
                

                
                $scope.atualizar = function(){
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl()+'/montadora?pagina='+$scope.pagina+'&tamanho='+$scope.tamanho,
                        headers: {
                            'Content-Type': 'application/json;charset=ISO-8859-1',
                        }
                    }).then(function successCallback(response) {
                        $scope.listagem = response.data.dados;
                        $scope.total = response.data.paginacao.total;
                        $scope.paginacao = [];
                        var i;
                        var indice = 0;
                        var inicio = ($scope.blocopaginacao-1) * 10 + 1 ;
                        var fim = inicio + 9;
                        if(fim>$scope.total) fim = $scope.total;
                        
                        
                        
                        
                        for(i=inicio;i<=fim;i++){
                           $scope.paginacao[indice] = i;
                           indice++;
                        }
                        $scope.carregado = "display";
                    }, function errorCallback(response) {
                        console.log("erro");
                    });

                }
                
                $scope.deletar = function (id) {

                    swal({
                        title: "Confirmação",
                        text: "Tem certeza que deseja excluir esta montadora?",
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#DD6B55",
                        confirmButtonText: "SIM",
                        closeOnConfirm: true
                    },
                    function () {
                        $http({
                            method: 'DELETE',
                            url: ConfigFactory.getUrl()+'/montadora/'+id,
                            headers: {
                                'Content-Type': 'application/json;charset=ISO-8859-1',
                            }
                        }).then(function successCallback(response) {
                            toastr.success(response.data.descricao, 'Sucesso')
                            $scope.atualizar();
                        }, function errorCallback(response) {

                        });
                    });

                };
                $scope.atualizar();

            }])
        .controller('MarcaFormController', ['$scope', '$location', '$http', '$routeParams','ConfigFactory', function ($scope, $location,$http, $routeParams, ConfigFactory) {

                
                $scope.buscar = function(id){
                    $http({
                        method: 'GET',
                        url: ConfigFactory.getUrl()+'/montadora/'+id,
                        headers: {
                            'Content-Type': 'application/json;charset=ISO-8859-1',
                        }
                    }).then(function successCallback(response) {
                       $scope.marca = response.data;
                        
                    }, function errorCallback(response) {

                    });
                    
                }
                
                
                $scope.cadastrar = function (marca) {
                    var metodo = "POST";
                    if(marca.id) metodo = "PUT";
                   
                    $http({
                        method: metodo,
                        url: ConfigFactory.getUrl()+'/montadora',
                        headers: {
                            'Content-Type': 'application/json;charset=ISO-8859-1',
                        },
                        data: marca
                    }).then(function successCallback(response) {
                        toastr.success(response.data.descricao, 'Sucesso')
                        $location.path('/marca');
                    }, function errorCallback(response) {

                    });



                };
                
                if($routeParams.id){
                    $scope.buscar($routeParams.id);
                    $scope.titulo = "Editar Montadora";
                }
                else{
                    $scope.titulo = "Nova Montadora";
                }


            }]);