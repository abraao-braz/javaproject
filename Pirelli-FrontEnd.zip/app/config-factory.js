angular.module('PirelliApp.configuracoes',[]).factory('ConfigFactory', function() {
    var logado = false;
    var tipo = 2;

    return {
        getUrl: function(){
            return "http://localhost:8080/Pirelli-Api/webresources";
        },
        getLogado: function(){
            return logado;
        },
        setLogado: function(valor){
            logado = valor;
        },
        getTipo: function(){
            return tipo;
        },
        setTipo: function(valor){
            tipo = valor;
        },      
        getClasse: function(){
            
          if(localStorage.getItem("pirelli.tipo")==='2') return "hidden";
          return "display";
        }
        
    };
});