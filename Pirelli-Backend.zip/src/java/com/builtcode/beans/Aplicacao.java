/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.builtcode.beans;

/**
 *
 * @author Fabio
 */
public class Aplicacao {
    private String id;
    private Produto produto;
    private Versao versao;
    private int ano;
    private String localizacao;
    private String homologado;
    private String velocidade;
    private Medida medida;
    private Modelo modelo;
    private String observacoes;
    private String ip7;
    private String carga;

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the produto
     */
    public Produto getProduto() {
        return produto;
    }

    /**
     * @param produto the produto to set
     */
    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    /**
     * @return the versao
     */
    public Versao getVersao() {
        return versao;
    }

    /**
     * @param versao the versao to set
     */
    public void setVersao(Versao versao) {
        this.versao = versao;
    }

    /**
     * @return the ano
     */
    public int getAno() {
        return ano;
    }

    /**
     * @param ano the ano to set
     */
    public void setAno(int ano) {
        this.ano = ano;
    }

    /**
     * @return the localizacao
     */
    public String getLocalizacao() {
        return localizacao;
    }

    /**
     * @param localizacao the localizacao to set
     */
    public void setLocalizacao(String localizacao) {
        this.localizacao = localizacao;
    }



    /**
     * @return the velocidade
     */
    public String getVelocidade() {
        return velocidade;
    }

    /**
     * @param velocidade the velocidade to set
     */
    public void setVelocidade(String velocidade) {
        this.velocidade = velocidade;
    }

    /**
     * @return the homologado
     */
    public String getHomologado() {
        return homologado;
    }

    /**
     * @param homologado the homologado to set
     */
    public void setHomologado(String homologado) {
        this.homologado = homologado;
    }

    /**
     * @return the medida
     */
    public Medida getMedida() {
        return medida;
    }

    /**
     * @param medida the medida to set
     */
    public void setMedida(Medida medida) {
        this.medida = medida;
    }

    /**
     * @return the modelo
     */
    public Modelo getModelo() {
        return modelo;
    }

    /**
     * @param modelo the modelo to set
     */
    public void setModelo(Modelo modelo) {
        this.modelo = modelo;
    }

    /**
     * @return the observacoes
     */
    public String getObservacoes() {
        return observacoes;
    }

    /**
     * @param observacoes the observacoes to set
     */
    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }

    /**
     * @return the ip7
     */
    public String getIp7() {
        return ip7;
    }

    /**
     * @param ip7 the ip7 to set
     */
    public void setIp7(String ip7) {
        this.ip7 = ip7;
    }

    /**
     * @return the carga
     */
    public String getCarga() {
        return carga;
    }

    /**
     * @param carga the carga to set
     */
    public void setCarga(String carga) {
        this.carga = carga;
    }


    
    
    
}
