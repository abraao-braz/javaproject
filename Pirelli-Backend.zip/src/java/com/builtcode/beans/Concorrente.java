/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.builtcode.beans;

/**
 *
 * @author Fabio
 */
public class Concorrente {
   private String id;
   private Produto produto;
   private Fabricante fabricante;
   private String produtoconcorrente;
   private String observacoes;

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }





    /**
     * @return the observacoes
     */
    public String getObservacoes() {
        return observacoes;
    }

    /**
     * @param observacoes the observacoes to set
     */
    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }

    /**
     * @return the produto
     */
    public Produto getProduto() {
        return produto;
    }

    /**
     * @param produto the produto to set
     */
    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    /**
     * @return the produtoconcorrente
     */
    public String getProdutoconcorrente() {
        return produtoconcorrente;
    }

    /**
     * @param produtoconcorrente the produtoconcorrente to set
     */
    public void setProdutoconcorrente(String produtoconcorrente) {
        this.produtoconcorrente = produtoconcorrente;
    }

    /**
     * @return the fabricante
     */
    public Fabricante getFabricante() {
        return fabricante;
    }

    /**
     * @param fabricante the fabricante to set
     */
    public void setFabricante(Fabricante fabricante) {
        this.fabricante = fabricante;
    }
   
   
}
